export class ShareConfig {
    get authApiURI() {
        return 'https://bleudeperse-artisanat.com';
        // return 'http://localhost:49864';
     } 
}
